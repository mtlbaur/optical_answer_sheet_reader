import logging

debug_enabled = None
debug_form_indexes = None
logging_level = logging.INFO
outpath = "out"
cfgpath = "cfg"
