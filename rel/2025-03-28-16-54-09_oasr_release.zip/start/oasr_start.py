from oasr.ui.main import init

if __name__ == "__main__":
    init()
